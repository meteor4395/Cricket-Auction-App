import streamlit as st
import pandas as pd
import random

# App title and layout
st.set_page_config(page_title="Cricket Auction App", layout="centered")
st.title("🏏 Cricket Auction App")
st.caption("Created by Devesh Chaudhari")

# Upload Excel file
uploaded_file = st.file_uploader("Upload Player List (Excel)", type=["xlsx"])
if uploaded_file:
    df = pd.read_excel(uploaded_file)

    if 'Player' not in df.columns:
        st.error("Excel must contain a 'Player' column.")
    else:
        # Initialize session state
        if 'auctioned_players' not in st.session_state:
            st.session_state.auctioned_players = []
        if 'current_player' not in st.session_state:
            st.session_state.current_player = None
        if 'sold_players' not in st.session_state:
            st.session_state.sold_players = []
        if 'unsold_players' not in st.session_state:
            st.session_state.unsold_players = []

        # Randomly pick a player
        if st.button("🔀 Shuffle & Pick Player"):
            remaining = df[~df['Player'].isin(st.session_state.auctioned_players)]
            if not remaining.empty:
                selected = remaining.sample(1).iloc[0]
                st.session_state.current_player = selected
                st.session_state.auctioned_players.append(selected['Player'])
            else:
                st.warning("🎉 All players have been auctioned.")

        # Display player details
        if st.session_state.current_player is not None:
            player = st.session_state.current_player
            st.subheader(f"🎯 {player['Player']}")
            st.text("Base Price: ₹20L
Step Up: ₹10L")

            col1, col2 = st.columns(2)
            with col1:
                team = st.selectbox("Select Team", ["Team A", "Team B", "Team C"], key="team_select")
                if st.button("✅ Mark as Sold at Base Price"):
                    st.session_state.sold_players.append({
                        'Player': player['Player'],
                        'Price': 20,
                        'Team': team
                    })
                    st.session_state.current_player = None
                    st.success(f"{player['Player']} sold to {team} for ₹20L")

            with col2:
                if st.button("❌ Mark as Unsold"):
                    st.session_state.unsold_players.append(player['Player'])
                    st.session_state.current_player = None
                    st.info(f"{player['Player']} marked as unsold.")

        # Show results
        if st.session_state.sold_players:
            st.subheader("✅ Sold Players")
            st.dataframe(pd.DataFrame(st.session_state.sold_players))

        if st.session_state.unsold_players:
            st.subheader("❌ Unsold Players")
            st.write(", ".join(st.session_state.unsold_players))
